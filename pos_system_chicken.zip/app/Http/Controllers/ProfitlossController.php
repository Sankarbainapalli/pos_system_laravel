<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProfitlossController extends Controller
{
    //
    public function profitloss(){

        return view('admin.profit&loss.list');
    
    }
}
